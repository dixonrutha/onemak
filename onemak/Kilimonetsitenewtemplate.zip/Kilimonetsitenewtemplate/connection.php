<?php
	$connect = mysql_connect('localhost','root');
	mysql_select_db("kilimo_net",$connect)or die(mysql_error());
?>